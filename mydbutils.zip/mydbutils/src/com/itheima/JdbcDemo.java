package com.itheima;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class JdbcDemo {

	public void insert() {

		Connection conn = null;
		PreparedStatement stmt = null;

		try {

			stmt = conn.prepareStatement("insert into product values(null,?,?,?)");

			// �滻ռλ��

			// ִ��sql���
			stmt.executeUpdate();

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			// �ͷ���Դ

		}

	}

	public void delete() {

		Connection conn = null;
		PreparedStatement stmt = null;

		try {

			stmt = conn.prepareStatement("delete from product where id=?");

			// �滻ռλ��

			// ִ��sql���
			stmt.executeUpdate();

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			// �ͷ���Դ

		}

	}

	public void update() {

		Connection conn = null;
		PreparedStatement stmt = null;

		try {

			stmt = conn.prepareStatement("update product set name=?, price=? where id=?");

			// �滻ռλ��

			// ִ��sql���
			stmt.executeUpdate();

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			// �ͷ���Դ

		}

	}
	
	public void query() {

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {

			stmt = conn.prepareStatement("select * from product where id=?");

			// �滻ռλ��

			// ִ��sql���
			rs = stmt.executeQuery();

			//���������... 
			
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			// �ͷ���Դ

		}

	}
	
}
