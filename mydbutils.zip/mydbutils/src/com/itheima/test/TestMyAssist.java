package com.itheima.test;

import java.util.List;

import org.junit.Test;

import com.itheima.assist.MyDBAssist;
import com.itheima.assist.handler.BeanHandler;
import com.itheima.assist.handler.BeanListHandler;
import com.itheima.domain.Product;
import com.wgs.utils.JDBCUtils;

public class TestMyAssist {
	
	
	@Test
	public void test1(){
		
		MyDBAssist assist= new MyDBAssist(JDBCUtils.getDataSource()); 
		
		assist.update("insert into product values(null,?,?,?)", new Object[]{"С��ͬѧ",10,299});
		
	}
	@Test
	public void testDelete(){
		
		MyDBAssist assist= new MyDBAssist(JDBCUtils.getDataSource()); 
		
		assist.update("delete from product where id=?", new Object[]{1});
		
	}
	@Test
	public void testQueryOne(){
		
		MyDBAssist assist= new MyDBAssist(JDBCUtils.getDataSource()); 
		
		Product product = (Product) assist.query("select * from product where id=?", new Object[]{12}, new BeanHandler(Product.class));
		
		System.out.println(product);
	}
	
	@Test
	public void testQueryAll(){
		
		MyDBAssist assist= new MyDBAssist(JDBCUtils.getDataSource()); 
		
		List<Product> list = (List<Product>) assist.query("select * from product", null, new BeanListHandler(Product.class));
		
		for (Product product : list) {
			System.out.println(product);
		}
	}
	
}
