package com.itheima.jdbc;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import org.junit.Test;

public class JdbcDemo {
	
	@Test
	public void test3() throws Exception{
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection conn = DriverManager.getConnection("jdbc:mysql:///mydb1", "root", "abc");
		
		PreparedStatement stmt = conn.prepareStatement("select * from product");
		
		
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()){
			
			// ���ÿ�е� ��Ӧ��ֵ 
			
		}
		
		
		ResultSetMetaData rsmd = rs.getMetaData();
		
		int columnCount = rsmd.getColumnCount();
		
		for (int i = 0; i < columnCount; i++) {
			
			String columnName = rsmd.getColumnName(i+1);
			
			// Product.java --- 
			
			
			System.out.println("���� : "+columnName);
			
		}
		
		System.out.println(columnCount +"+++++++++++++++++");
	}
	
	
	
	@Test
	public void test2() throws Exception{
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection conn = DriverManager.getConnection("jdbc:mysql:///mydb1", "root", "abc");
		
		
		PreparedStatement stmt = conn.prepareStatement("insert into product values(null,?,?,?)");
//		PreparedStatement stmt = conn.prepareStatement("???????????????????????????????");
		
		// ����Ԫ������Ϣ
		ParameterMetaData pmd = stmt.getParameterMetaData();
		
		//���ռλ���ĸ��� 
		int count = pmd.getParameterCount();
		
		System.out.println(count+"===============");
		
		
		//�м���ռλ�����滻���� , ��˳���� .
		stmt.setString(1, "aaa");
		stmt.setInt(2, 30);
		
		
		for (int i = 0; i < count; i++) {
			
//			stmt.setInt(2, 30);
//			stmt.setObject(i+1, x);
			
		}
		
		
		// ִ��sql���
//		stmt.executeUpdate();
		
	}
	
	
	@Test
	public void test1() throws Exception{
		
		Class.forName("com.mysql.jdbc.Driver");
		
		
		Connection conn = DriverManager.getConnection("jdbc:mysql:///mydb1", "root", "abc");
		
		DatabaseMetaData dbms = conn.getMetaData();
		
		System.out.println(dbms.getURL());
		System.out.println(dbms.getDriverMajorVersion());
		System.out.println(dbms.getDriverName());
		
		System.out.println(conn);
	}
	
}
