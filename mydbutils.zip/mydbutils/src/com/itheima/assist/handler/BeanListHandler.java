package com.itheima.assist.handler;

import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

import org.apache.jasper.tagplugins.jstl.core.Param;

//  Ҫ��:
//      ��װ������¼��

//  Ҫ��װ�����ݵ� �е����� ������ ��   Ŀ��java��� �ֶε����ƺ��� ����һ�� 
//  product (id int, name varchar(), count int, price double)                 
//  Product.java
public class BeanListHandler implements ResultSetHandler {
	
	private Class clazz;
	
	public BeanListHandler(Class clazz){
		this.clazz = clazz;
	}
	
	/**
	 *   {@link Param}  rs , this params ... 
	 */
	@Override
	public Object handle(ResultSet rs) {
		
		try{
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			List list = new ArrayList();
			
			int columnCount = rsmd.getColumnCount();
			
			while(rs.next()){
				
				Object obj = clazz.newInstance();
				
				for (int i = 0; i < columnCount; i++) {
					
					// id , name , price, count
					String columnName = rsmd.getColumnName(i+1);
					
					Field field = clazz.getDeclaredField(columnName);
					
//					Object object = rs.getObject(i+1);
					Object value = rs.getObject(columnName);
					field.setAccessible(true);  //  �������� 
					field.set(obj, value);
				}
				list.add(obj);
			}
			
			return list;
		}catch(Exception e){
			
			e.printStackTrace();
		}
		
		return null;
	}

}
