package com.itheima.assist.handler;

import java.sql.ResultSet;

public interface ResultSetHandler {
	
	public Object handle(ResultSet rs);
	
}
