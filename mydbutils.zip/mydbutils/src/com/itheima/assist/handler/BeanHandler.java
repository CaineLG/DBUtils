package com.itheima.assist.handler;

import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

//  Ҫ��:
//      ��װ������¼��

//  Ҫ��װ�����ݵ� �е����� ������ ��   Ŀ��java��� �ֶε����ƺ��� ����һ�� 
//  product (id int, name varchar(), count int, price double)                 
//  Product.java
public class BeanHandler implements ResultSetHandler {
	
	private Class clazz;
	
	public BeanHandler(Class clazz){
		this.clazz = clazz;
	}
	

	@Override
	public Object handle(ResultSet rs) {
		
		try{
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			
			int columnCount = rsmd.getColumnCount();
			
			Object obj = clazz.newInstance();
			if(rs.next()){
				
				
				for (int i = 0; i < columnCount; i++) {
					
					// id , name , price, count
					String columnName = rsmd.getColumnName(i+1);
					
					Field field = clazz.getDeclaredField(columnName);
					
//					Object object = rs.getObject(i+1);
					Object value = rs.getObject(columnName);
					field.setAccessible(true);  //  �������� 
					field.set(obj, value);
				}
			}
			
			return obj;
		}catch(Exception e){
			
			e.printStackTrace();
		}
		
		return null;
	}

}
